<?php

namespace Blocksy\Extensions\WoocommerceExtra;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ProductWaitlistLayer {
	public function __construct() {
		add_filter(
			'blocksy_woo_single_options_layers:defaults',
			array(
				$this,
				'register_layer_defaults',
			)
		);

		add_filter(
			'blocksy_woo_single_options_layers:extra',
			array(
				$this,
				'register_layer_options',
			)
		);

		add_filter(
			'blocksy_woo_single_right_options_layers:defaults',
			array( $this, 'register_layer_defaults' )
		);

		add_filter(
			'blocksy_woo_single_right_options_layers:extra',
			array( $this, 'register_layer_options' )
		);

		add_action(
			'blocksy:woocommerce:product:custom:layer',
			array(
				$this,
				'render_layer',
			)
		);

		add_action(
			'blocksy:woocommerce:quick-view:add-to-cart:after',
			array( $this, 'render_quick_view_layer' ),
			10
		);

		add_shortcode(
			'blocksy_waitlist',
			array(
				$this,
				'shortcode_render',
			)
		);

		add_filter(
			'do_shortcode_tag',
			function ( $output, $tag, $attr ) {
				if ( 'blocksy_waitlist' === $tag ) {
					wp_enqueue_style( 'blocksy-ext-woocommerce-extra-product-waitlist-styles' );
				}

				return $output;
			},
			10,
			3
		);
	}

	public static function get_users_count( $product_id ) {
		$waitlist_users = count( ProductWaitlistDb::get_waitlists_from_db( wc_get_product( $product_id ), '', '', true ) );

		$message = blocksy_companion_safe_sprintf(
			// translators: %1$s is the number of users, %2$s is the plural form (user/users)
			__( '%1$s %2$s joined the waitlist for this item.', 'blocksy-companion' ),
			blocksy_companion_html_tag(
				'span',
				array(),
				$waitlist_users,
			),
			$string = _n(
				'user',
				'users',
				$waitlist_users,
				'blocksy-companion'
			)
		);

		return array(
			'waitlist_users' => $waitlist_users,
			'message'        => $message,
		);
	}

	public static function get_stock_status( $product ) {
		/**
		 * Filters the stock status Product Waitlist uses to decide whether to show its form.
		 *
		 * @since 2.1.62
		 *
		 * @param string      $stock_status Stock status of the product.
		 * @param \WC_Product $product      Product or variation being displayed.
		 */
		return apply_filters(
			'blocksy:ext:woocommerce-extra:product-waitlist:stock-status',
			$product->get_stock_status(),
			$product
		);
	}

	private static function need_to_show() {
		global $product;

		if ( ! $product ) {
			return array(
				'need_to_show' => false,
				'visible'      => false,
				'product_id'   => null,
			);
		}

		$need_to_show = false;
		$visible      = false;

		$product_id = $product->get_id();

		if (
			self::get_stock_status( $product ) === 'outofstock'
			||
			(
				self::get_stock_status( $product ) === 'onbackorder'
				&&
				blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'waitlist_allow_backorders', 'no' ) === 'yes'
			)
		) {
			$need_to_show = true;

			if ( ! $product->is_type( 'variable' ) ) {
				$visible = true;
			}
		}

		if ( $product->is_type( 'variable' ) ) {
			$maybe_current_variation = null;

			if ( blocksy_companion_theme_functions()->blocksy_manager() ) {
				$maybe_current_variation = blocksy_companion_theme_functions()->blocksy_manager()
					->woocommerce
					->retrieve_product_default_variation( $product );
			}

			if ( $maybe_current_variation ) {
				$product_id = $maybe_current_variation->get_id();

				if (
					self::get_stock_status( $maybe_current_variation ) === 'outofstock'
					||
					(
						self::get_stock_status( $maybe_current_variation ) === 'onbackorder'
						&&
						blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'waitlist_allow_backorders', 'no' ) === 'yes'
					)
				) {
					$need_to_show = true;
					$visible      = true;
				} else {
					$need_to_show = false;
				}
			}

			$get_variations = true;
			$all_variations = blocksy_companion_get_ext( 'woocommerce-extra' )
				->utils
				->get_available_variations( $product->get_id() );

			if ( Utils::TOO_MUCH_AVAILABLE_VARIATIONS === $all_variations ) {
				$get_variations = false;
			}

			if ( $get_variations ) {
				foreach ( $all_variations as $variation ) {
					if (
						(
							isset( $variation['backorders_allowed'] )
							&&
							$variation['backorders_allowed']
							&&
							blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'waitlist_allow_backorders', 'no' ) === 'no'
						)
						||
						(
							isset( $variation['is_in_stock'] )
							&&
							$variation['is_in_stock']
						)
					) {
						continue;
					}

					$need_to_show = true;

					if ( $need_to_show ) {
						break;
					}
				}
			} else {
				$need_to_show = true;
			}
		}

		return array(
			'need_to_show' => $need_to_show,
			'visible'      => $visible,
			'product_id'   => $product_id,
		);
	}

	public static function get_content() {
		$waitlist_user_visibility = blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'waitlist_user_visibility', 'no' );

		if (
			'yes' === $waitlist_user_visibility
			&&
			! is_user_logged_in()
		) {
			return;
		}

		$waitlist_conditions = blocksy_companion_theme_functions()->blocksy_get_theme_mod(
			'waitlist_conditions',
			array(
				array(
					'type'    => 'include',
					'rule'    => 'everywhere',
					'payload' => array(),
				),
			)
		);

		$conditions_manager = new \Blocksy\ConditionsManager();

		$is_matching_conditions = $conditions_manager->condition_matches(
			$waitlist_conditions,
			array( 'relation' => 'OR' )
		);

		if ( ! $is_matching_conditions ) {
			return;
		}

		$visibility = self::need_to_show();

		if ( ! $visibility['need_to_show'] ) {
			return;
		}

		$state             = 'hidden';
		$unsubscribe_token = '';

		if ( $visibility['visible'] ) {
			$state = 'visible';

			$waitlist = ProductWaitlistDb::get_waitlist( wc_get_product( $visibility['product_id'] ), '', false );

			if ( ! empty( $waitlist ) ) {
				$state = 'subscribed';

				$unsubscribe_token = $waitlist[0]->unsubscribe_token;

				if ( '1' === $waitlist[0]->confirmed ) {
					$state = 'subscribed-confirmed';
				}
			}
		}

		return blocksy_companion_render_view(
			__DIR__ . '/views/form.php',
			array(
				'state'             => $state,
				'unsubscribe_token' => $unsubscribe_token,
				'product_id'        => $visibility['product_id'],
			)
		);
	}

	public function shortcode_render() {
		$content = self::get_content();

		if ( ! $content ) {
			return;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $content;
	}

	public function render_quick_view_layer() {
		$content = self::get_content();

		if ( ! $content ) {
			return;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $content;
	}

	public function render_layer( $layer ) {
		if ( 'product_waitlist' !== $layer['id'] ) {
			return;
		}

		$content = self::get_content();

		if ( ! $content ) {
			return;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $content;
	}

	public function register_layer_defaults( $opt ) {
		return array_merge(
			$opt,
			array(
				array(
					'id'      => 'product_waitlist',
					'enabled' => false,
				),
			)
		);
	}

	public function register_layer_options( $opt ) {
		return array_merge(
			$opt,
			array(
				'product_waitlist' => array(
					'label'   => __( 'Waitlist Form', 'blocksy-companion' ),
					'options' => array(
						'spacing' => array(
							'label'      => __( 'Bottom Spacing', 'blocksy-companion' ),
							'type'       => 'ct-slider',
							'min'        => 0,
							'max'        => 100,
							'value'      => 35,
							'responsive' => true,
							'sync'       => array(
								'id' => 'woo_single_layout_skip',
							),
						),
					),
				),
			)
		);

		return $opt;
	}
}
