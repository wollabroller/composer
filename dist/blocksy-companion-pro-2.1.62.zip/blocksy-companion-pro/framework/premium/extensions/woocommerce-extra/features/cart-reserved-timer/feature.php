<?php

namespace Blocksy\Extensions\WoocommerceExtra;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CartReservedTimer {
	private $skip_stock_filter    = false;
	private $stock_owner_products = array();
	private $held_stock           = array();

	public function get_dynamic_styles_data( $args ) { // phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable -- filter callback signature
		return array(
			'path' => __DIR__ . '/dynamic-styles.php',
		);
	}

	public function __construct() {
		add_filter(
			'blocksy:ext:woocommerce-extra:attributes_terms_stock_result',
			function ( $data ) {
				if ( ! self::should_use_cart_reservation() ) {
					return $data;
				}

				$storage = new CartReservationStorage();

				// During quantity input generation: exclude current user's reservation
				// During product display: include ALL reservations
				$exclude_current_user = $this->should_exclude_current_session();

				$reserved_variations = $storage->get_reserved_quantity_for_variations(
					array_keys( $data ),
					$exclude_current_user && WC()->session
					? array( 'exclude_session_id' => WC()->session->get_customer_id() )
					: array()
				);

				foreach ( $data as $variation_id => $variation_data ) {
					if (
					isset( $variation_data['_stock_status'] )
					&&
					'instock' !== $variation_data['_stock_status']
					) {
						continue;
					}

					if (
					! isset( $variation_data['_manage_stock'] )
					||
					'yes' !== $variation_data['_manage_stock']
					) {
						continue;
					}

					$reserved = $reserved_variations[ $variation_id ] ?? 0;

					$stock_quantity = isset( $variation_data['_stock'] ) ? (int) $variation_data['_stock'] : 0;
					$available      = max( 0, $stock_quantity - $reserved );

					if ( $available <= 0 ) {
						if ( isset( $variation_data['_stock'] ) && '' !== $variation_data['_stock'] ) {
							$data[ $variation_id ]['_stock'] = '0';
						}

						$data[ $variation_id ]['_stock_status'] = 'outofstock';
					}
				}

				return $data;
			},
			10,
			1
		);

		add_action(
			'wp_enqueue_scripts',
			function () {
				if ( ! function_exists( 'get_plugin_data' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}

				$data = get_plugin_data( BLOCKSY__FILE__ );

				if ( ! class_exists( 'Blocksy_Header_Builder_Render' ) ) {
					return;
				}

				$render        = new \Blocksy_Header_Builder_Render();
				$has_mini_cart = $render->contains_item( 'cart' );

				if (
					is_admin()
					||
					(
						blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_reserved_timer_in_cart', 'yes' ) === 'no'
						&&
						blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_reserved_timer_in_mini_cart', 'no' ) === 'no'
					)
					||
					(
						blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_reserved_timer_in_mini_cart', 'no' ) === 'yes'
						&&
						! $has_mini_cart
					)
				) {
					return;
				}

				wp_enqueue_style(
					'blocksy-ext-woocommerce-extra-cart-reserved-timer-styles',
					BLOCKSY_URL .
						'framework/premium/extensions/woocommerce-extra/static/bundle/cart-reserved-timer.min.css',
					array( 'blocksy-ext-woocommerce-extra-styles' ),
					$data['Version']
				);
			},
			50
		);

		add_filter(
			'blocksy_customizer_options:woocommerce:general:end',
			function ( $opts ) {
				$opts['has_cart_reserved_timer_panel'] = blocksy_companion_get_options(
					__DIR__ . '/options.php',
					array(),
					false
				);

				return $opts;
			},
			55
		);

		add_filter(
			'blocksy:frontend:dynamic-js-chunks',
			function ( $chunks ) {
				if ( ! class_exists( 'WC_AJAX' ) ) {
					return $chunks;
				}

				$cache_manager = new \Blocksy\CacheResetManager();

				$trigger = array(
					array(
						'trigger'  => $cache_manager->is_there_any_page_caching() ? 'initial-mount' : 'slight-mousemove',
						'selector' => '[class*="ct-cart-reserved-timer"]',
					),

					array(
						'selector'    => '[class*="ct-cart-reserved-timer"]',
						'trigger'     => 'jquery-event',
						'matchTarget' => false,
						'events'      => array(
							'added_to_cart',
							'removed_from_cart',
							'wc_fragments_refreshed',
							'updated_cart_totals',
						),
					),
				);

				$chunks[] = array(
					'id'          => 'blocksy_ext_woo_extra_cart_reserved_timer',
					'selector'    => '[class*="ct-cart-reserved-timer"]',
					'mountOnLoad' => true,
					'trigger'     => $trigger,
					'url'         => blocksy_companion_theme_functions()->blocksy_cdn_url(
						BLOCKSY_URL . 'framework/premium/extensions/woocommerce-extra/static/bundle/cart-reserved-timer.js'
					),
					'version'     => blocksy_companion_get_version(),
				);

				return $chunks;
			}
		);

		add_action(
			'wp',
			function () {
				if ( self::should_use_cart_reservation() ) {
					if ( ! WC()->session ) {
						return;
					}

					// empty cart for current session if reservation expired
					$session_id  = WC()->session->get_customer_id();
					$storage     = new CartReservationStorage();
					$reservation = $storage->get_current_reservation( $session_id );

					if ( $reservation ) {
						$current_time            = time();
						$woo_reserved_timer_time = blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_reserved_timer_time', 10 );
						$reserved_until          = strtotime( $reservation->last_modified ) + ( $woo_reserved_timer_time * 60 );

						if ( $current_time >= $reserved_until ) {
							WC()->cart->empty_cart();
							$storage->remove_cart_reservation( $session_id );
						}
					}
				}
			},
			20
		);

		add_action(
			'wp',
			function () {
				if ( blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_reserved_timer_in_cart', 'yes' ) === 'yes' ) {
					add_action(
						'woocommerce_cart_contents',
						function () {
                        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							echo $this->cart_page_render( 'cart' );
						}
					);
				}

				if ( blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_reserved_timer_in_mini_cart', 'no' ) === 'yes' ) {
					add_action(
						'woocommerce_before_mini_cart',
						function () {
                        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							echo $this->cart_page_render( 'mini-cart' );
						}
					);
				}
			},
			25
		);

		// Set validation flag BEFORE WooCommerce processes add-to-cart (priority 20)
		// https://github.com/woocommerce/woocommerce/blob/trunk/plugins/woocommerce/includes/class-wc-form-handler.php
		add_action(
			'wp_loaded',
			function () {
				// Regular add-to-cart form submission
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
				if ( isset( $_REQUEST['add-to-cart'] ) ) {
					$this->skip_stock_filter = true;
				}

				// Cart update form submission
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
				if ( isset( $_REQUEST['update_cart'] ) ) {
					$this->skip_stock_filter = true;
				}
			},
			19
		);

		// Set validation flag BEFORE WooCommerce AJAX (priority 0)
		// https://github.com/woocommerce/woocommerce/blob/trunk/plugins/woocommerce/includes/class-wc-ajax.php
		add_action(
			'template_redirect',
			function () {
				if ( ! wp_doing_ajax() ) {
					return;
				}

				$validation_actions = array(
					'woocommerce_add_to_cart',
					'woocommerce_checkout',
					'blocksy_update_qty_cart',
				);

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$action = isset( $_REQUEST['action'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ) : '';

				if ( in_array( $action, $validation_actions, true ) ) {
					$this->skip_stock_filter = true;
				}
			},
			-1
		);

		// Set flag during offcanvas cart quantity field generation
		add_action(
			'blocksy:ext:woocommerce-extra:offcanvas-cart:quantity-input:before',
			function () {
				$this->skip_stock_filter = true;
			}
		);

		add_action(
			'blocksy:ext:woocommerce-extra:offcanvas-cart:quantity-input:after',
			function () {
				$this->skip_stock_filter = false;
			}
		);

		// Set flag during cart page quantity field generation
		add_action(
			'woocommerce_before_cart_contents',
			function () {
				$this->skip_stock_filter = true;
			}
		);

		add_action(
			'woocommerce_after_cart_contents',
			function () {
				$this->skip_stock_filter = false;
			}
		);

		// Set flag during checkout page quantity field generation
		add_action(
			'blocksy:ext:woocommerce-extra:checkout:quantity-input:before',
			function () {
				$this->skip_stock_filter = true;
			}
		);

		add_action(
			'blocksy:ext:woocommerce-extra:checkout:quantity-input:after',
			function () {
				$this->skip_stock_filter = false;
			}
		);

		add_action(
			'init',
			function () {
				if ( self::should_use_cart_reservation() ) {
					$hooks_to_listen = array(
						'woocommerce_add_to_cart',
						'woocommerce_remove_cart_item',
						'woocommerce_cart_item_restored',
						'woocommerce_cart_item_removed',
						'woocommerce_after_cart_item_quantity_update',
					);

					foreach ( $hooks_to_listen as $hook ) {
						add_action(
							$hook,
							function () {
								if ( ! WC()->session || ! WC()->cart ) {
									return;
								}

								$session_id = WC()->session->get_customer_id();
								$cart_items = array();

								foreach ( WC()->cart->get_cart() as $item ) {
									$reserved_product_id = isset( $item['variation_id'] ) && (int) $item['variation_id'] > 0
									? (int) $item['variation_id']
									: (int) $item['product_id'];

									$cart_items[] = array(
										'product_id' => $reserved_product_id,
										'quantity'   => $item['quantity'],
									);
								}

								$last_modified = gmdate( 'Y-m-d H:i:s', time() );

								$storage = new CartReservationStorage();
								$storage->set_cart_reservation( $session_id, $cart_items, $last_modified );
							}
						);
					}

					add_action(
						'woocommerce_cart_emptied',
						function () {
							if ( WC()->session ) {
								$storage = new CartReservationStorage();
								$storage->remove_cart_reservation( WC()->session->get_customer_id() );
							}
						}
					);

					add_action( 'woocommerce_after_product_object_save', array( $this, 'clear_stock_owner_products' ) );
					add_action( 'deleted_post', array( $this, 'clear_stock_owner_products' ) );

					add_filter( 'woocommerce_cart_item_required_stock_is_not_enough', array( $this, 'cart_has_insufficient_stock' ), 10, 2 );

					add_filter(
						'blocksy:ext:woocommerce-extra:stock-scarcity:stock-quantity',
						function ( $quantity, $product ) {
							if ( ( is_cart() || is_checkout() ) && ! $this->skip_stock_filter ) {
								return $quantity;
							}

							return min(
								$quantity,
								$this->get_available_stock(
									$product,
									array( 'exclude_current_session' => $this->should_exclude_current_session() )
								)
							);
						},
						10,
						2
					);

					add_filter( 'blocksy:ext:woocommerce-extra:product-waitlist:stock-status', array( $this, 'filter_waitlist_stock_status' ), 10, 2 );
					add_filter( 'woocommerce_post_class', array( $this, 'filter_product_post_class' ), 10, 2 );
					add_filter( 'blocksy:woocommerce:product-card:badges', array( $this, 'filter_archive_badges' ) );
					add_filter( 'blocksy:woocommerce:single:after-sale-badge', array( $this, 'filter_single_badges' ) );
					add_action( 'woocommerce_checkout_order_created', array( $this, 'clear_held_stock' ), PHP_INT_MAX );

					add_filter( 'woocommerce_get_availability_text', array( $this, 'filter_availability_text' ), 5, 2 );
					add_filter( 'woocommerce_get_availability_class', array( $this, 'filter_availability_class' ), 5, 2 );
					add_filter( 'woocommerce_quantity_input_args', array( $this, 'filter_quantity_input_args' ), 10, 2 );
					add_filter( 'woocommerce_quantity_input_max', array( $this, 'filter_quantity_input_max' ), 10, 2 );
					add_filter( 'woocommerce_available_variation', array( $this, 'filter_available_variation' ), 10, 3 );
					add_filter( 'woocommerce_product_add_to_cart_url', array( $this, 'filter_add_to_cart_url' ), 10, 2 );
					add_filter( 'woocommerce_product_add_to_cart_text', array( $this, 'filter_add_to_cart_text' ), 10, 2 );
					add_filter( 'woocommerce_product_add_to_cart_description', array( $this, 'filter_add_to_cart_description' ), 10, 2 );
					add_filter( 'woocommerce_loop_add_to_cart_args', array( $this, 'filter_loop_add_to_cart_args' ), 10, 2 );
					add_filter( 'woocommerce_product_supports', array( $this, 'filter_product_supports' ), 10, 3 );
					add_filter( 'woocommerce_add_cart_item_data', array( $this, 'validate_cart_item_data' ), 10, 4 );
					add_filter( 'woocommerce_add_cart_item', array( $this, 'validate_new_cart_item' ), PHP_INT_MAX );
					add_filter( 'woocommerce_update_cart_validation', array( $this, 'validate_cart_update' ), 10, 4 );
					add_action( 'woocommerce_store_api_validate_add_to_cart', array( $this, 'validate_store_api_add_to_cart' ), 10, 2 );
					add_action( 'woocommerce_store_api_validate_cart_item', array( $this, 'validate_store_api_cart_item' ) );
					add_filter( 'woocommerce_store_api_product_quantity_maximum', array( $this, 'filter_store_api_maximum' ), 10, 3 );
					add_filter( 'woocommerce_store_api_cart_item_quantity_validation', array( $this, 'validate_store_api_quantity' ), 10, 4 );

					foreach ( array( 'woocommerce_simple_add_to_cart', 'woocommerce_variation_add_to_cart' ) as $hook ) {
						add_action( $hook, array( $this, 'replace_simple_add_to_cart' ), 0 );
						add_action( $hook, array( $this, 'restore_simple_add_to_cart' ), PHP_INT_MAX );
					}
					add_filter( 'woocommerce_grouped_product_list_column_quantity', array( $this, 'filter_grouped_quantity' ), 10, 2 );
					add_filter( 'rest_request_after_callbacks', array( $this, 'filter_store_api_products' ), 10, 3 );
					add_filter( 'woocommerce_hydration_request_after_callbacks', array( $this, 'filter_store_api_products' ), 10, 3 );
				}
			}
		);

		add_action( 'wp_ajax_blc_ext_cart_reserved_timer_sync', array( $this, 'sync_timers' ) );
		add_action( 'wp_ajax_nopriv_blc_ext_cart_reserved_timer_sync', array( $this, 'sync_timers' ) );
	}

	private function should_exclude_current_session() {
		return $this->skip_stock_filter || is_cart() || is_checkout() || WC()->is_store_api_request();
	}

	private function get_available_stock( $product, $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'exclude_current_session' => false,
				'include_held_stock'      => false,
			)
		);

		$product_ids = $this->get_stock_owner_products( $product );

		$storage  = new CartReservationStorage();
		$reserved = array_sum(
			$storage->get_reserved_quantity_for_variations(
				$product_ids,
				$args['exclude_current_session'] && WC()->session
				? array( 'exclude_session_id' => WC()->session->get_customer_id() )
				: array()
			)
		);

		if ( $args['include_held_stock'] ) {
			$order_id = 0;

			if ( WC()->session ) {
				$order_id = absint( WC()->session->get( 'order_awaiting_payment' ) );

				if ( ! $order_id ) {
					$order_id = absint( WC()->session->get( 'store_api_draft_order' ) );
				}
			}

			$held_key = $product->get_id() . ':' . $order_id;

			if ( ! isset( $this->held_stock[ $held_key ] ) ) {
				$this->held_stock[ $held_key ] = wc_get_held_stock_quantity( $product, $order_id );
			}

			$reserved += $this->held_stock[ $held_key ];
		}

		return max( 0, $product->get_stock_quantity() - $reserved );
	}

	public function clear_stock_owner_products() {
		$this->stock_owner_products = array();
	}

	public function clear_held_stock() {
		$this->held_stock = array();
	}

	public function filter_waitlist_stock_status( $stock_status, $product ) {
		if ( ! $product->managing_stock() || ! $product->is_in_stock() ) {
			return $stock_status;
		}

		$available = $this->get_available_stock(
			$product,
			array(
				'exclude_current_session' => $this->should_exclude_current_session(),
			)
		);

		if ( $available > 0 ) {
			return $stock_status;
		}

		if ( $product->backorders_allowed() ) {
			return 'onbackorder';
		}

		return 'outofstock';
	}

	public function filter_product_post_class( $classes, $product ) {
		if ( ! $this->is_reserved_out( $product ) ) {
			return $classes;
		}

		$classes   = array_diff( $classes, array( 'instock' ) );
		$classes[] = 'outofstock';

		return $classes;
	}

	public function filter_archive_badges( $badges ) {
		$badge = $this->get_reserved_out_badge( 'archive' );

		if ( $badge ) {
			$badges[] = $badge;
		}

		return $badges;
	}

	public function filter_single_badges( $badges ) {
		global $blocksy_is_quick_view;

		$location = 'single';

		if ( $blocksy_is_quick_view ) {
			$location = 'archive';
		}

		$badge = $this->get_reserved_out_badge( $location );

		if ( $badge ) {
			$badges[] = $badge;
		}

		return $badges;
	}

	private function get_reserved_out_badge( $location ) {
		global $product;

		if ( ! $this->is_reserved_out( $product ) ) {
			return '';
		}

		return blocksy_companion_theme_functions()->blocksy_get_woo_out_of_stock_badge(
			array(
				'location' => $location,
			)
		);
	}

	private function get_stock_owner_products( $product ) {
		$stock_owner_id = $product->get_stock_managed_by_id();

		if ( isset( $this->stock_owner_products[ $stock_owner_id ] ) ) {
			return $this->stock_owner_products[ $stock_owner_id ];
		}

		$product_ids = array( $stock_owner_id );
		$stock_owner = $product;

		if ( $stock_owner_id !== $product->get_id() ) {
			$stock_owner = wc_get_product( $stock_owner_id );
		}

		if ( $stock_owner && $stock_owner->is_type( 'variable' ) && $stock_owner->managing_stock() ) {
			$variation_ids = $stock_owner->get_children();

			update_meta_cache( 'post', $variation_ids );

			foreach ( $variation_ids as $variation_id ) {
				if ( ! wc_string_to_bool( get_post_meta( $variation_id, '_manage_stock', true ) ) ) {
					$product_ids[] = $variation_id;
				}
			}
		}

		$this->stock_owner_products[ $stock_owner_id ] = $product_ids;
		return $product_ids;
	}

	private function is_reserved_out( $product ) {
		return $product && $product->managing_stock() && ! $product->backorders_allowed()
			&& $product->is_in_stock() && $this->get_available_stock(
				$product,
				array(
					'exclude_current_session' => $this->should_exclude_current_session(),
				)
			) <= 0;
	}

	public function filter_availability_text( $text, $product ) {
		if ( ! $product->managing_stock() || ! $product->is_in_stock() ) {
			return $text;
		}

		$quantity = $this->get_available_stock(
			$product,
			array(
				'exclude_current_session' => $this->should_exclude_current_session(),
			)
		);

		if ( $quantity >= $product->get_stock_quantity() ) {
			return $text;
		}

		if ( $quantity > 0 ) {
			$limit_quantity = function ( $stock_quantity ) use ( $quantity ) {
				return min( $stock_quantity, $quantity );
			};

			add_filter( 'woocommerce_format_stock_quantity', $limit_quantity );

			$text = wc_format_stock_for_display( $product );

			remove_filter( 'woocommerce_format_stock_quantity', $limit_quantity );

			return $text;
		}

		if ( ! $product->backorders_allowed() ) {
			return __( 'Out of stock', 'blocksy-companion' );
		}

		if ( $product->backorders_require_notification() ) {
			return __( 'Available on backorder', 'blocksy-companion' );
		}

		return '';
	}

	public function filter_availability_class( $availability_class, $product ) {
		if ( ! $product->managing_stock() || ! $product->is_in_stock() ) {
			return $availability_class;
		}

		if ( $this->get_available_stock(
			$product,
			array(
				'exclude_current_session' => $this->should_exclude_current_session(),
			)
		) > 0 ) {
			return $availability_class;
		}

		return $product->backorders_allowed() ? 'available-on-backorder' : 'out-of-stock';
	}

	public function replace_simple_add_to_cart() {
		global $product;

		$hook     = current_filter();
		$priority = has_action( $hook, 'woocommerce_simple_add_to_cart' );

		if ( false === $priority || ! $this->is_reserved_out( $product ) ) {
			return;
		}

		remove_action( $hook, 'woocommerce_simple_add_to_cart', $priority );
		add_action( $hook, array( $this, 'render_reserved_stock' ), $priority );
	}

	public function restore_simple_add_to_cart() {
		$hook     = current_filter();
		$priority = has_action( $hook, array( $this, 'render_reserved_stock' ) );

		if ( false === $priority ) {
			return;
		}

		remove_action( $hook, array( $this, 'render_reserved_stock' ), $priority );
		add_action( $hook, 'woocommerce_simple_add_to_cart', $priority );
	}

	public function render_reserved_stock() {
		global $product;

		if ( ! $this->is_reserved_out( $product ) ) {
			woocommerce_simple_add_to_cart();
			return;
		}

		if ( $product->is_purchasable() ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo wc_get_stock_html( $product );
		}
	}

	public function filter_grouped_quantity( $html, $product ) {
		return $this->is_reserved_out( $product ) ? '' : $html;
	}

	public function filter_store_api_products( $response, $handler, $request ) {
		if ( 'GET' !== $request->get_method() || ! preg_match( '#^/wc/store(?:/v[0-9]+)?/products(?:/[0-9]+)?/?$#', wp_parse_url( $request->get_route(), PHP_URL_PATH ) ) ) {
			return $response;
		}

		if ( is_wp_error( $response ) || ! $response instanceof \WP_REST_Response || 200 !== $response->get_status() ) {
			return $response;
		}

		$data = $response->get_data();

		if ( isset( $data['id'] ) ) {
			$data = $this->filter_store_api_product( $data );
		} else {
			$data = array_map( array( $this, 'filter_store_api_product' ), $data );
		}

		$response->set_data( $data );
		return $response;
	}

	private function filter_store_api_product( $data ) {
		$product = wc_get_product( $data['id'] );

		if ( $this->is_reserved_out( $product ) ) {
			$data['is_in_stock'] = false;
		}

		if ( $product && $product->managing_stock() && 'no_amount' !== get_option( 'woocommerce_stock_format' ) ) {
			$available = $this->get_available_stock(
				$product,
				array(
					'exclude_current_session' => $this->should_exclude_current_session(),
					'include_held_stock'      => true,
				)
			);

			if ( $available <= wc_get_low_stock_amount( $product ) ) {
				$data['low_stock_remaining'] = $available;
			}
		}

		return $data;
	}

	public function filter_add_to_cart_url( $url, $product ) {
		return $this->is_reserved_out( $product ) ? $product->get_permalink() : $url;
	}

	public function filter_add_to_cart_text( $text, $product ) {
		return $this->is_reserved_out( $product ) ? __( 'Read more', 'blocksy-companion' ) : $text;
	}

	public function filter_add_to_cart_description( $description, $product ) {
		if ( ! $this->is_reserved_out( $product ) ) {
			return $description;
		}

		/* translators: %s: product name. */
		return sprintf( __( 'Read more about &ldquo;%s&rdquo;', 'blocksy-companion' ), $product->get_name() );
	}

	public function filter_loop_add_to_cart_args( $args, $product ) {
		if ( $this->is_reserved_out( $product ) && isset( $args['class'] ) ) {
			if ( isset( $args['attributes']['type'] ) ) {
				$args['attributes']['disabled']      = 'disabled';
				$args['attributes']['aria-disabled'] = 'true';
			}
			unset( $args['aria-describedby_text'] );
			$args['class'] = implode( ' ', array_diff( explode( ' ', $args['class'] ), array( 'ajax_add_to_cart', 'add_to_cart_button' ) ) );
		}

		return $args;
	}

	public function filter_product_supports( $supports, $feature, $product ) {
		if ( 'ajax_add_to_cart' === $feature && $this->is_reserved_out( $product ) ) {
			return false;
		}

		return $supports;
	}

	public function filter_available_variation( $data, $variable, $variation ) {
		$data['max_qty'] = $this->filter_quantity_input_max( $data['max_qty'], $variation );

		if ( $this->is_reserved_out( $variation ) ) {
			$data['is_in_stock'] = false;
		}

		return $data;
	}

	public function filter_quantity_input_args( $args, $product ) {
		$args['max_value'] = $this->filter_quantity_input_max( $args['max_value'], $product );
		return $args;
	}

	public function filter_quantity_input_max( $maximum, $product ) {
		if ( ! $product || ! $product->managing_stock() || $product->backorders_allowed() ) {
			return $maximum;
		}

		$available = $this->get_available_stock(
			$product,
			array(
				'exclude_current_session' => $this->should_exclude_current_session(),
			)
		);

		return '' === $maximum || $maximum < 0 ? $available : min( $maximum, $available );
	}

	private function get_cart_quantity( $product ) {
		$quantities = WC()->cart ? WC()->cart->get_cart_item_quantities() : array();
		return $quantities[ $product->get_stock_managed_by_id() ] ?? 0;
	}

	private function get_quantity_error( $product, $quantity ) {
		if ( ! $product || ! $product->managing_stock() || $product->backorders_allowed() ) {
			return '';
		}

		$available = $this->get_available_stock(
			$product,
			array(
				'exclude_current_session' => true,
				'include_held_stock'      => true,
			)
		);

		if ( $quantity <= $available ) {
			return '';
		}

		return sprintf(
			/* translators: 1: product name, 2: available quantity. */
			__( 'You cannot add that amount of &quot;%1$s&quot; to the cart because there is not enough stock (%2$s remaining).', 'blocksy-companion' ),
			$product->get_name(),
			$available
		);
	}

	private function check_add_to_cart_quantity( $product, $quantity ) {
		if ( ! $product ) {
			return;
		}

		$error = $this->get_quantity_error( $product, $quantity + $this->get_cart_quantity( $product ) );

		if ( $error ) {
			if ( WC()->is_store_api_request() ) {
				throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'blocksy_reserved_stock', esc_html( $error ), 400 );
			}

			throw new \Exception( esc_html( $error ) );
		}
	}

	public function validate_cart_item_data( $data, $product_id, $variation_id, $quantity ) {
		$product = wc_get_product( $variation_id ? $variation_id : $product_id );

		if ( $product && ! $product->is_sold_individually() ) {
			$this->check_add_to_cart_quantity( $product, $quantity );
		}

		return $data;
	}

	public function validate_new_cart_item( $cart_item ) {
		$this->check_add_to_cart_quantity( $cart_item['data'], $cart_item['quantity'] );
		return $cart_item;
	}

	public function validate_cart_update( $passed, $cart_item_key, $values, $quantity ) {
		if ( ! $passed || $quantity <= 0 || empty( $values['data'] ) ) {
			return $passed;
		}

		$error = $this->get_quantity_error( $values['data'], $quantity + $this->get_cart_quantity( $values['data'] ) - $values['quantity'] );

		if ( $error ) {
			wc_add_notice( $error, 'error' );
			return false;
		}

		return $passed;
	}

	public function cart_has_insufficient_stock( $is_not_enough, $product ) {
		if ( $this->get_quantity_error( $product, $this->get_cart_quantity( $product ) ) ) {
			add_filter( 'woocommerce_format_stock_quantity', array( $this, 'format_cart_stock_error_quantity' ), 10, 2 );
			return true;
		}

		return $is_not_enough;
	}

	public function format_cart_stock_error_quantity( $quantity, $product ) {
		remove_filter( 'woocommerce_format_stock_quantity', array( $this, 'format_cart_stock_error_quantity' ), 10 );

		return min(
			$quantity,
			$this->get_available_stock(
				$product,
				array(
					'exclude_current_session' => true,
					'include_held_stock'      => true,
				)
			)
		);
	}

	public function validate_store_api_add_to_cart( $product, $request ) {
		$this->check_add_to_cart_quantity( $product, $request['quantity'] );
	}

	public function validate_store_api_cart_item( $product ) {
		$error = $this->get_quantity_error( $product, $this->get_cart_quantity( $product ) );

		if ( $error ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'blocksy_reserved_stock', esc_html( $error ), 400 );
		}
	}

	public function validate_store_api_quantity( $valid, $quantity, $product, $cart_item ) {
		if ( is_wp_error( $valid ) || $quantity <= 0 ) {
			return $valid;
		}

		$error = $this->get_quantity_error( $product, $quantity + $this->get_cart_quantity( $product ) - $cart_item['quantity'] );

		return $error ? new \WP_Error( 'blocksy_reserved_stock', $error ) : $valid;
	}

	public function filter_store_api_maximum( $maximum, $product, $cart_item ) {
		if ( ! $product->managing_stock() || $product->backorders_allowed() ) {
			return $maximum;
		}

		$available = $this->get_available_stock(
			$product,
			array(
				'exclude_current_session' => true,
				'include_held_stock'      => true,
			)
		);

		if ( $cart_item ) {
			$available -= $this->get_cart_quantity( $product ) - $cart_item['quantity'];
		}

		return min( $maximum, max( 0, $available ) );
	}

	public function sync_timers() {
		wp_send_json_success(
			array(
				'cart'      => $this->cart_page_render( 'cart' ),
				'mini_cart' => $this->cart_page_render( 'mini-cart' ),
			)
		);
	}

	public function cart_page_render( $class_suffix = 'cart' ) {
		$classes = array( 'ct-cart-reserved-timer-placeholder-' . $class_suffix );

		if ( ! WC()->session ) {
			return blocksy_companion_html_tag( 'div', array( 'class' => join( ' ', $classes ) ), '' );
		}

		$session_id = WC()->session->get_customer_id();

		if ( ! $session_id ) {
			return blocksy_companion_html_tag( 'div', array( 'class' => join( ' ', $classes ) ), '' );
		}

		$storage     = new CartReservationStorage();
		$reservation = $storage->get_current_reservation( $session_id );

		if ( ! $reservation ) {
			return blocksy_companion_html_tag( 'div', array( 'class' => join( ' ', $classes ) ), '' );
		}

		$current_time            = time();
		$woo_reserved_timer_time = blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_reserved_timer_time', 10 );
		$reserved_until          = strtotime( $reservation->last_modified ) + ( $woo_reserved_timer_time * 60 );

		$remaining = $reserved_until - $current_time;

		if ( $remaining <= 0 ) {
			return blocksy_companion_html_tag( 'div', array( 'class' => join( ' ', $classes ) ), '' );
		}

		$remain_minutes = intdiv( $remaining, 60 );
		$remain_seconds = $remaining % 60;

		$date = gmdate( 'Y-m-d H:i:s', $reserved_until );

		$countdown = blocksy_companion_html_tag(
			'time',
			array( 'datetime' => $date ),
			blocksy_companion_html_tag( 'span', array(), str_pad( $remain_minutes, 2, '0', STR_PAD_LEFT ) ) .
				':' .
			blocksy_companion_html_tag( 'span', array(), str_pad( $remain_seconds, 2, '0', STR_PAD_LEFT ) )
		);

		$message = str_replace(
			'{time}',
			$countdown,
			blocksy_companion_sanitize_html_for_display(
				blocksy_companion_theme_functions()->blocksy_get_theme_mod(
					'woo_reserved_timer_message',
					// phpcs:ignore WordPress.WP.I18n.NoHtmlWrappedStrings
					__( '<p><strong>🔥 Hurry up! Your selected items are in high demand!</strong><br>Your cart will be reserved for {time} minutes.</p>', 'blocksy-companion' )
				)
			)
		);

		$classes = array( 'ct-cart-reserved-timer-' . $class_suffix );

		return blocksy_companion_html_tag(
			'div',
			array(
				'class'        => join( ' ', $classes ),
				'data-timeout' => $remaining,
			),
			blocksy_companion_html_tag( 'div', array( 'class' => 'ct-cart-reserved-timer-message' ), $message )
		);
	}

	public static function should_use_cart_reservation() {
		return (
			blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_reserved_timer_in_cart', 'yes' ) === 'yes'
			||
			blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_reserved_timer_in_mini_cart', 'no' ) === 'yes'
		);
	}
}
