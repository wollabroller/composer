<?php

namespace Blocksy\Extensions\WoocommerceExtra;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/helpers.php';

class QuickView {
	public function get_dynamic_styles_data( $args ) {
		return array(
			'path' => __DIR__ . '/dynamic-styles.php',
		);
	}

	public function __construct() {
		new QuickViewIntegrations();

		add_filter(
			'blocksy_woo_card_options:additional_actions',
			function (
				$actions
			) {
				$actions[] = array(
					'id'    => 'has_archive_quick_view',
					'label' => __( 'Quick View Button', 'blocksy-companion' ),
				);

				return $actions;
			},
			3
		);

		// Archive product card toolbar — priority 1200 keeps the quick view button
		// last in the toolbar (after wishlist 1000 and compare 1100).
		add_filter(
			'blocksy:options:woocommerce:archive:card-type:output_product_toolbar',
			function ( $components ) {
				$quick_view = blocksy_companion_output_quick_view_link();

				if ( ! empty( $quick_view ) ) {
					$components[] = $quick_view;
				}

				return $components;
			},
			1200
		);

		// Merge the quick view data-* attributes into the products container.
		add_filter(
			'blocksy:woocommerce:products-container:attr',
			function ( $attr ) {
				return array_merge( blocksy_companion_quick_view_attr(), $attr );
			}
		);

		add_filter(
			'blocksy:frontend:dynamic-js-chunks',
			function ( $chunks ) {
				if ( ! class_exists( 'WC_AJAX' ) ) {
					return $chunks;
				}

				$chunks[] = array(
					'id'           => 'blocksy_ext_woo_extra_quick_view',
					'selector'     => implode(
						', ',
						array(
							'.ct-open-quick-view',
							'[data-quick-view="image"] .ct-media-container',
							'[data-quick-view="card"] > .type-product',
						)
					),
					'url'          => blocksy_companion_theme_functions()->blocksy_cdn_url(
						BLOCKSY_URL . 'framework/premium/extensions/woocommerce-extra/static/bundle/quick-view.js'
					),
					'deps'         => array(
						'underscore',
						'wc-add-to-cart-variation',
						'wp-util',
					),
					'global_data'  => array(
						array(
							'var'  => 'wc_add_to_cart_variation_params',
							'data' => array(
								'wc_ajax_url'           => \WC_AJAX::get_endpoint( '%%endpoint%%' ),
								'i18n_no_matching_variations_text' => esc_attr__( 'Sorry, no products matched your selection. Please choose a different combination.', 'blocksy-companion' ),
								'i18n_make_a_selection_text' => esc_attr__( 'Please select some product options before adding this product to your cart.', 'blocksy-companion' ),
								'i18n_unavailable_text' => esc_attr__( 'Sorry, this product is unavailable. Please choose a different combination.', 'blocksy-companion' ),
							),
						),
					),
					'trigger'      => 'click',
					'ignore_click' => implode(
						', ',
						array(
							"[data-quick-view='card'] > * [data-product_id]",
							"[data-quick-view='card'] > * .added_to_cart",
							"[data-quick-view='card'] > * .ct-woo-card-extra > *",
						)
					),
					'has_loader'   => array(
						'type'  => blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woocommerce_quick_view_trigger', 'button' ) === 'button' ? 'button' : 'modal',
						'class' => 'quick-view-modal',
					),
					'version'      => blocksy_companion_get_version(),
				);

				return $chunks;
			}
		);

		add_filter(
			'blocksy:general:ct-scripts-localizations',
			function ( $data ) {
				$data['dynamic_styles_selectors'][] = array(
					'selector' => '.product',
					'url'      => blocksy_companion_theme_functions()->blocksy_cdn_url(
						BLOCKSY_URL . 'framework/premium/extensions/woocommerce-extra/static/bundle/quick-view-lazy.min.css'
					),
				);

				return $data;
			}
		);

		add_action(
			'wp_ajax_blocsky_get_woo_quick_view',
			array(
				$this,
				'get_quick_view',
			)
		);

		add_action(
			'wp_ajax_nopriv_blocsky_get_woo_quick_view',
			array(
				$this,
				'get_quick_view',
			)
		);

		add_filter(
			'blocksy_customizer_options:woocommerce:general:end',
			function ( $opts ) {
				$opts['has_quick_view_panel'] = blocksy_companion_get_options(
					__DIR__ . '/options.php',
					array(),
					false
				);

				return $opts;
			}
		);

		add_action(
			'blocksy:woocommerce:quick-view:add-to-cart:after',
			function () {
				$layout = blocksy_companion_theme_functions()->blocksy_get_theme_mod(
					'woo_single_layout',
					blocksy_companion_theme_functions()->blocksy_get_woo_single_layout_defaults()
				);

				$product_view_type = blocksy_companion_theme_functions()->blocksy_get_theme_mod(
					'product_view_type',
					'default-gallery'
				);

				if (
					'top-gallery' === $product_view_type
					||
					'columns-top-gallery' === $product_view_type
				) {
					$woo_single_split_layout = blocksy_companion_theme_functions()->blocksy_get_theme_mod(
						'woo_single_split_layout',
						array(
							'left'  => blocksy_companion_theme_functions()->blocksy_get_woo_single_layout_defaults( 'left' ),
							'right' => blocksy_companion_theme_functions()->blocksy_get_woo_single_layout_defaults( 'right' ),
						)
					);

					$layout = array_merge(
						$woo_single_split_layout['left'],
						$woo_single_split_layout['right']
					);
				}

				$actions_layer = array_values(
					array_filter(
						$layout,
						function ( $k ) {
							return 'product_actions' === $k['id'];
						}
					)
				);

				if ( $actions_layer && blocksy_companion_theme_functions()->blocksy_manager() ) {
					blocksy_companion_theme_functions()->blocksy_manager()
						->woocommerce
						->single
						->additional_actions
						->render( array_shift( $actions_layer ) );
				}
			},
			15
		);
	}

	public function get_quick_view() {
		if ( function_exists( 'YITH_Name_Your_Price_Frontend' ) ) {
			YITH_Name_Your_Price_Frontend();
		}

		global $product;
		global $post;

		global $blocksy_is_quick_view;

		/**
		 * Fires so content blocks can register their display hooks.
		 *
		 * Re-dispatched here for the quick view request, which renders product
		 * markup outside the normal `wp` lifecycle, so content blocks hooked
		 * into the single product layout are attached for the quick view output.
		 *
		 * @since 1.7.63
		 */
		do_action( 'blocksy:content-blocks:display-hooks' );

		$blocksy_is_quick_view = true;

		add_filter(
			'blocksy:woocommerce:product-view:attr',
			function ( $attributes ) {
				unset( $attributes['data-gallery'], $attributes['data-thumbs'] );
				return $attributes;
			}
		);

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['product_id'] ) ) {
			wp_die();
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$product = wc_get_product( absint( wp_unslash( $_GET['product_id'] ) ) );

		$variation = null;

		if ( $product && get_class( $product ) === 'WC_Product_Variation' ) {
			global $blocksy_current_variation;

			$variation = $product;
			$product   = wc_get_product( $variation->get_parent_id() );

			$blocksy_current_variation = $variation;

			$permalink = $variation->get_permalink();

			parse_str( wp_parse_url( $permalink, PHP_URL_QUERY ), $res );

			foreach ( $res as $key => $val ) {
				$_REQUEST[ $key ] = $val;
				$_GET[ $key ]     = $val;
			}
		}

		if (
			! $product
			||
			! blocksy_companion_is_post_viewable( array( 'post' => $product->get_id() ) )
		) {
			wp_send_json_error();
		}

		$GLOBALS['product'] = $product; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global

		$id = $product->get_id();

		$post = get_post( $id );

		$is_in_stock = true;

		if ( ! $product->managing_stock() && ! $product->is_in_stock() ) {
			$is_in_stock = false;
		}

		remove_action(
			'woocommerce_product_thumbnails',
			'woocommerce_show_product_thumbnails',
			20
		);

		$is_customize_preview = (
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			isset( $_GET['is_customizer'] )
			&&
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			sanitize_text_field( wp_unslash( $_GET['is_customizer'] ) )
		);

		$content = blocksy_companion_render_view(
			__DIR__ . '/view.php',
			array(
				'id'                   => $id,
				'product'              => $product,
				'variation'            => $variation,
				'is_customize_preview' => $is_customize_preview,
			)
		);

		ob_start();
		if ( function_exists( 'wc_get_template' ) ) {
			wc_get_template( 'single-product/add-to-cart/variation.php' );
		}
		$body_html = ob_get_clean();

		wp_send_json_success(
			array(
				'quickview' => $content,
				'body_html' => $body_html,
			)
		);
	}
}
