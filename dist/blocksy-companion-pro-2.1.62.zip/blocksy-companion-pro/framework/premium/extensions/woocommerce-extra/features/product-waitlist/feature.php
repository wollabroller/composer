<?php

namespace Blocksy\Extensions\WoocommerceExtra;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/helpers.php';

class ProductWaitlist {
	public function get_dynamic_styles_data( $args ) {
		return array(
			'path' => __DIR__ . '/dynamic-styles.php',
		);
	}

	public function __construct() {
		new ProductWaitlistDb();
		new ProductWaitlistLayer();

		new ProductWaitlistDashboard();
		new ProductWaitlistMailer();

		new ProductWaitlistAccount();

		add_filter(
			'blocksy_customizer_options:woocommerce:general:end',
			function ( $opts ) {
				$opts['has_product_waitlist_panel'] = blocksy_companion_get_options(
					__DIR__ . '/customizer-options.php',
					array(),
					false
				);

				return $opts;
			},
			55
		);

		add_filter(
			'blocksy:general:ct-scripts-localizations',
			function ( $data ) {
				$waitlist = ProductWaitlistDb::get_waitlist();

				if ( ! function_exists( 'get_plugin_data' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}

				$plugin_data = get_plugin_data( BLOCKSY__FILE__ );

				$data['dynamic_styles']['waitlist'] = add_query_arg(
					'ver',
					$plugin_data['Version'],
					blocksy_companion_theme_functions()->blocksy_cdn_url(
						BLOCKSY_URL .
							'framework/premium/extensions/woocommerce-extra/static/bundle/single-product-waitlist.min.css',
					)
				);

				$data['blc_ext_waitlist'] = array(
					'user_logged_in'            => is_user_logged_in() ? 'yes' : 'no',
					'waitlist_allow_backorders' => blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'waitlist_allow_backorders', 'no' ),
					// The frontend serializes this back into the
					// blc_products_waitlist cookie for logged out visitors, so
					// it has to hold the random unsubscribe token of each row
					// and never the sequential subscription_id. A guessable id
					// in a client controlled cookie is a bearer credential
					// anyone can walk.
					'list'                      => array(
						'v'     => ProductWaitlistDb::$cookie_version,
						'items' => array_values(
							array_map(
								function ( $item ) {
									return $item->unsubscribe_token;
								},
								$waitlist
							)
						),
					),
				);

				return $data;
			}
		);

		add_action(
			'wp_login',
			function ( $user_login, $user ) {
				if ( ! $user ) {
					return;
				}

				$user_id = $user->get( 'ID' );

				ProductWaitlistDb::update_for_user( $user_id );
			},
			10,
			2
		);

		add_action(
			'wp_enqueue_scripts',
			function () {
				if ( ! function_exists( 'get_plugin_data' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}

				$data = get_plugin_data( BLOCKSY__FILE__ );

				$storage  = new \Blocksy\Extensions\WoocommerceExtra\Storage();
				$settings = $storage->get_settings();

				wp_register_style(
					'blocksy-ext-woocommerce-extra-product-waitlist-styles',
					BLOCKSY_URL .
						'framework/premium/extensions/woocommerce-extra/static/bundle/single-product-waitlist.min.css',
					array( 'blocksy-ext-woocommerce-extra-styles' ),
					$data['Version']
				);

				if (
					is_admin()
					||
					! is_singular( 'product' )
					||
					(
						is_singular( 'product' )
						&&
						! blocksy_companion_theme_functions()->blocksy_has_product_specific_layer( 'product_waitlist' )
						&&
						! is_customize_preview()
					)
				) {
					return;
				}

				wp_enqueue_style( 'blocksy-ext-woocommerce-extra-product-waitlist-styles' );
			},
			50
		);

		add_filter(
			'blocksy:frontend:dynamic-js-chunks',
			function ( $chunks ) {
				if ( ! class_exists( 'WC_AJAX' ) ) {
					return $chunks;
				}

				$chunks[] = array(
					'id'       => 'blocksy_ext_woo_extra_waitlist',
					'selector' => '.product .ct-product-waitlist',
					'trigger'  => array(
						array(
							'trigger'  => 'jquery-event',
							'events'   => array(
								'found_variation',
								'reset_data',
							),
							'selector' => '.product .ct-product-waitlist',
						),
					),
					'url'      => blocksy_companion_theme_functions()->blocksy_cdn_url(
						BLOCKSY_URL .
							'framework/premium/extensions/woocommerce-extra/static/bundle/product-waitlist.js'
					),
					'version'  => blocksy_companion_get_version(),
				);

				$chunks[] = array(
					'id'       => 'blocksy_ext_woo_extra_waitlist',
					'selector' => implode(
						', ',
						array(
							'.product .ct-product-waitlist-form',
						)
					),
					'url'      => blocksy_companion_theme_functions()->blocksy_cdn_url(
						BLOCKSY_URL .
							'framework/premium/extensions/woocommerce-extra/static/bundle/product-waitlist.js'
					),
					'trigger'  => 'submit',
					'version'  => blocksy_companion_get_version(),
				);

				$chunks[] = array(
					'id'       => 'blocksy_ext_woo_extra_waitlist',
					'selector' => implode(
						', ',
						array(
							'.product .ct-waitlist-subscribed-state .unsubscribe',
							'.waitlist-product-actions .unsubscribe',
							'.waitlist-product-mobile-actions .unsubscribe',
						)
					),
					'url'      => blocksy_companion_theme_functions()->blocksy_cdn_url(
						BLOCKSY_URL .
							'framework/premium/extensions/woocommerce-extra/static/bundle/product-waitlist.js'
					),
					'trigger'  => 'click',
					'version'  => blocksy_companion_get_version(),
				);

				$cache_manager = new \Blocksy\CacheResetManager();

				if ( $cache_manager->is_there_any_page_caching() ) {
					$chunks[] = array(
						'id'       => 'blocksy_ext_woo_extra_waitlist',
						'selector' => implode(
							', ',
							array(
								'.product .ct-product-waitlist-form',
							)
						),
						'url'      => blocksy_companion_theme_functions()->blocksy_cdn_url(
							BLOCKSY_URL .
								'framework/premium/extensions/woocommerce-extra/static/bundle/product-waitlist.js'
						),
						'version'  => blocksy_companion_get_version(),
					);
				}

				return $chunks;
			}
		);

		add_filter(
			'blocksy-companion:pro:header:account:dropdown-items',
			function ( $layer_settings ) {
				if ( function_exists( 'wc_get_endpoint_url' ) ) {
					$layer_settings['waitlist'] = array(
						'label'   => __( 'Waitlist', 'blocksy-companion' ),
						'options' => array(
							'label' => array(
								'type'   => 'text',
								'value'  => __( 'Waitlist', 'blocksy-companion' ),
								'design' => 'inline',
								'sync'   => array(
									'shouldSkip' => true,
								),
							),
						),
					);
				}

				return $layer_settings;
			}
		);

		add_filter(
			'woocommerce_available_variation',
			function ( $result, $product, $variation ) {
				$maybe_user_email = '';

				if ( is_user_logged_in() ) {
					$maybe_user_email = wp_get_current_user()->user_email;
				}

				$product = wc_get_product( $variation->get_id() );

				$waitlist   = ProductWaitlistDb::get_waitlist( $product, $maybe_user_email, false );
				$count_data = ProductWaitlistLayer::get_users_count( $product->get_id() );

				$result['blocksy_waitlist'] = array(
					'unsubscribe_token'      => ! empty( $waitlist ) ? $waitlist[0]->unsubscribe_token : '',
					'waitlist_users'         => $count_data['waitlist_users'],
					'waitlist_users_message' => $count_data['message'],
				);

				$stock_quantity = $variation->get_stock_quantity();

				if ( 'instock' !== ProductWaitlistLayer::get_stock_status( $variation ) ) {
					$stock_quantity = 0;
				}

				$result['blocksy_stock_quantity'] = $stock_quantity;

				return $result;
			},
			10,
			3
		);
	}
}
