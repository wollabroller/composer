<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BlocksyExtensionLocalGoogleFontsPreBoot {
	private $all_google_fonts = null;

	public function __construct() {
		add_action(
			'admin_enqueue_scripts',
			function () {
				if ( ! function_exists( 'get_plugin_data' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}

				$data = get_plugin_data( BLOCKSY__FILE__ );

				if ( ! function_exists( 'blocksy_is_dashboard_page' ) ) {
					return;
				}
				if ( ! blocksy_is_dashboard_page() ) {
					return;
				}

				wp_enqueue_script(
					'blocksy-ext-local-google-fonts-admin-dashboard-scripts',
					BLOCKSY_URL . 'framework/premium/extensions/local-google-fonts/dashboard-static/bundle/main.js',
					array( 'ct-options-scripts', 'ct-dashboard-scripts' ),
					$data['Version'],
					false
				);
			}
		);
	}

	public function ext_action( $payload ) {
		$ext = \Blocksy\Plugin::instance()->extensions->get( 'local-google-fonts' );

		if (
			! isset( $payload['type'] )
			||
			! isset( $payload['settings'] )
			||
			! $ext
		) {
			return;
		}

		if ( 'start-persistence' === $payload['type'] ) {
			$ext->start_fonts_persistence( $payload['settings'] );
		}

		if ( 'persist-single-font' === $payload['type'] ) {
			$ext->persist_fonts_for( $payload['settings'] );
		}

		if ( 'conclude-persistence' === $payload['type'] ) {
			$payload['settings'] = $ext->conclude_fonts_persistence( $payload['settings'] );
			/**
			 * Fires when the dynamic CSS caches should be invalidated.
			 *
			 * Listeners drop their generated CSS files/transients so the
			 * next request regenerates them.
			 *
			 * @since 1.6.2
			 * @since 1.8.0 Renamed from `blocksy:dynamic-css:regenere_css_files`.
			 */
			do_action( 'blocksy:dynamic-css:refresh-caches' );
		}

		if ( 'preload-urls' === $payload['type'] ) {
			$ext->preload_urls( $payload['settings'] );
		}

		return $this->ext_data(
			array(
				'settings' => $payload['settings'],
			)
		);
	}

	public function ext_data( $args = array() ) {
		$all_google_fonts     = array();
		$all_google_fonts_map = array();

		if ( class_exists( '\Blocksy\FontsManager' ) ) {
			if ( null === $this->all_google_fonts ) {
				$m = new \Blocksy\FontsManager();

				$this->all_google_fonts = $m->get_googgle_fonts();
			}

			$all_google_fonts = $this->all_google_fonts;

			foreach ( $all_google_fonts as $font ) {
				$all_google_fonts_map[ $font['family'] ] = array(
					'label' => $font['family'],
				);
			}
		}

		$settings = get_option(
			'blocksy_ext_local_google_fonts_settings',
			array(
				'cached_css' => '',
				'fonts'      => array(),
				'last_saved' => null,
			)
		);

		if ( ! $settings ) {
			$settings = array(
				'cached_css' => '',
				'fonts'      => array(),
				'last_saved' => null,
			);
		}

		return wp_parse_args(
			$args,
			array(
				'settings'             => $settings,
				'all_google_fonts'     => $all_google_fonts,
				'all_google_fonts_map' => $all_google_fonts_map,
			)
		);
	}
}
